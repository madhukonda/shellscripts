#!/bin/bash

case $1 in
"Hello")
   echo " Greeted  with Hello"
  ;;

"5")
    echo "You entered value 5"

  ;;


"rao")
  echo "You entered rao  as the input"
  ;;

"babu")
   echo "You entered babu  as the input"
  ;;


 *)
   echo "I dont know what  you entered"
  ;;

esac