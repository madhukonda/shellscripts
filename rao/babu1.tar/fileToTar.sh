#!/bin/bash

 tar -cvf  $1.tar  $2